# Giới thiệu
tattools01 là 1 thư viện dùng để ghi tham số vào ổ cứng