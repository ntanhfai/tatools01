from tatools01.md_word.convert_md_to_word import md2w_main

def main():
    print("Chạy md2w để chuyển Markdown → Word")
    md2w_main()
